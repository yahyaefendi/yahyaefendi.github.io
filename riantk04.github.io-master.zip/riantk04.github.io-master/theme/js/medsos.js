var medsos = [
	[
		'https://www.linkedin.com/in/rian-tri-kusuma-010683119/',
		'theme/img/icon/icon_in.png',
	],
	[
		'https://www.facebook.com/trikusumarian',
		'theme/img/icon/icon_fb.png',
	],
	[
		'https://www.instagram.com/riantk/',
		'theme/img/icon/icon_ig.png',
	],
]