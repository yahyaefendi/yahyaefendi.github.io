var menu = [
	[
		'home',
		'fa fa-home',
		'Home'
	],
	[
		'about_me',
		'fa fa-user',
		'About Me'
	],
	[
		'my_education',
		'fas fa-graduation-cap',
		'My Education'
	],
	[
		'my_job_experience',
		'fas fa-briefcase',
		'My Job Experience'
	],
	[
		'my_portofolio',
		'fab fa-squarespace',
		'My Portofolio'
	],
	[
		'contact_me',
		'fa fa-phone',
		'Contact Me'
	],
]
